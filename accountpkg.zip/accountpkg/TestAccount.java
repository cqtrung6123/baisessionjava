package accountpkg;

//Importing packages
import bankpkg.Bank;
import java.util.Scanner;

public class TestAccount {
    /**
     *
     * @param args the command line argument
     */
    public static void main(String[] args) {
        try {



        //Declare a String array to store account details
        String[] accountDetals = new String[5];
        //Declare a String array to store bank details
        String[] bankDetails = new String[3];
        //Instantiate the Scanner class
        Scanner input = new Scanner(System.in);

        //Accept the account details
        System.out.print("Enter Account Number: ");
        accountDetals[0] = input.nextLine();//accept account number
        System.out.print("Enter Name: ");
        accountDetals[1] = input.nextLine();//accept account holder name
        System.out.print("Enter Account Type: ");
        accountDetals[2] = input.nextLine();//accept account Type
        System.out.print("Enter Balance: ");
        accountDetals[3] = input.nextLine();//accept balance
        System.out.print("Enter Number of Days:");//accept number of day
        accountDetals[4]=input.nextLine();

        //Accept the bank details
        System.out.print("Enter Bank ID: ");
        bankDetails[0] = input.nextLine();//accept bank id
        System.out.print("Enter Bank Name: ");
        bankDetails[1] = input.nextLine();//accept bank name
        System.out.print("Enter Bank Branch: ");
        bankDetails[2] = input.nextLine();//accept bank branch

        System.out.println("--------------------------------------");
        //Declare and instantiate onject of type SavingAccount
        SavingAccount objAccount1=new SavingAccount(accountDetals[0],
                accountDetals[1],accountDetals[2],
                Double.parseDouble(accountDetals[3]),
                Integer.parseInt(accountDetals[4])
        );
       //display the deatils of objaccoun1 object
        objAccount1.displayDetails();
        System.out.println("-----------------------------------");
        //declare and instantitste object of type bank
        Bank objBank1=new Bank();
        //add the bank deatails of objbank1 object
        objBank1.addBankDetails(bankDetails);
        //dicplay bank deatails of objBank objecty
        objBank1.displayBankDetails();
       //check account balance
        objAccount1.checkBalance(accountDetals[0]);
        //deposit cash into the account
        System.out.print("Enter Deposit Amount:");
        double deposit=Double.parseDouble(input.nextLine());
        //invoke the depositCash() method
        objAccount1.depositCash(accountDetals[0],deposit );
        //withdraw cash form the account
        System.out.print("Enter Withdrawal Amount:");
        double withdraw=Double.parseDouble(input.nextLine());
        //invoke the withdrawCash() method
        objAccount1.withdrawCash(accountDetals[0],withdraw);
        }catch (ArrayIndexOutOfBoundsException ex){
           //display an error message when exception is raised
            System.out.println("Error:Array Index Out of Bounds");
        }catch (NumberFormatException ex){
            //display anerror message when exception is reaised
            System.out.println("Error: Illegal Argument," + ex.getMessage());
        }
     }
}
